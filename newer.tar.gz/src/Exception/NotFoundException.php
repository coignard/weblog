<?php

declare(strict_types=1);

namespace Weblog\Exception;

final class NotFoundException extends \Exception {}
